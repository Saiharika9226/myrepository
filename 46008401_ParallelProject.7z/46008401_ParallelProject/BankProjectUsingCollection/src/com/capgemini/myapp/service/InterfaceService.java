
/**
 * @author Sai Harika.R
 * Date 18/10/2019
 * 
 * Description 
 * Interface for the Service class
 */
package com.capgemini.myapp.service;

import com.capgemini.myapp.pojo.Pojo;

public interface InterfaceService {
	public int bankAccountCreateService(Pojo bankBeanObjCreateAccountObj);

	public float balanceService(Pojo bankBeanShowBalObj);

	public float depositService(Pojo bankBeanDepObj);

	public float withdrawService(Pojo bankBeanWithdrawObj);

	public float transferService(Pojo bankBeanFundObj);

	public String printTransaction();
}
