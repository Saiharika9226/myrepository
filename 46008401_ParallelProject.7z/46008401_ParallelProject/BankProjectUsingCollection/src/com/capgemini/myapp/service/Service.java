/**
 * @author Sai Harika.R
 * Date 18/10/2019
 * 
 * Description 
 * Here the methods for the business logic is performed and this class implementing the methods  from the interface
 *
 */

package com.capgemini.myapp.service;

import java.util.HashMap;

import java.util.Map;
import com.capgemini.myapp.dao.Dao;
import com.capgemini.myapp.pojo.Pojo;

public class Service implements InterfaceService {
	HashMap<Long, String> transactionStorage = new HashMap<Long, String>();
	Dao dao = new Dao();

	public int bankAccountCreateService(Pojo bankBeanObjCreateAccountObj) {
		int value = dao.addCustomer(bankBeanObjCreateAccountObj);
		return value;

	}

	public float balanceService(Pojo bankBeanShowBalObj) {

		float value = 0;
		if (dao.hashMethod().isEmpty()) {
			System.out.println("Please create an account first.");
		} else {
			if (dao.hashMethod().containsKey(bankBeanShowBalObj.getAccNo())) {
				System.out.println(
						"Your Account Balance is: " + dao.hashMethod().get(bankBeanShowBalObj.getAccNo()).getBalance());
				value = dao.hashMethod().get(bankBeanShowBalObj.getAccNo()).getBalance();
			} else {
				System.out.println("No such Account Exist.");
			}
		}
		return value;
	}

	public float depositService(Pojo bankBeanDepObj) {
		float value = 0;
		if (dao.hashMethod().isEmpty()) {
			System.out.println("Please create an account first.");
		} else {
			if (dao.hashMethod().containsKey(bankBeanDepObj.getAccNo())) {
				float dep = bankBeanDepObj.getDepAmount()
						+ dao.hashMethod().get(bankBeanDepObj.getAccNo()).getBalance();
				dao.hashMethod().get(bankBeanDepObj.getAccNo()).setBalance(dep);
				value = dao.hashMethod().get(bankBeanDepObj.getAccNo()).getBalance();
				System.out.println("Deposited successfully.");
				System.out.println(
						"Your account balance is: " + dao.hashMethod().get(bankBeanDepObj.getAccNo()).getBalance());
				long accountNumber = bankBeanDepObj.getAccNo();
				String message = accountNumber + " is deposited with amount of" + bankBeanDepObj.getDepAmount();
				transactionStorage.put(accountNumber, message);
			}

			else {

				System.out.println("No such Account Exist.");
			}
		}
		return value;
	}

	public float withdrawService(Pojo bankBeanWithdrawObj) {
		float value = 0;
		if (dao.hashMethod().isEmpty()) {
			System.out.println("Please create an account first.");

		} else

		{
			if (bankBeanWithdrawObj.getWithdrawAmount() > dao.hashMethod().get(bankBeanWithdrawObj.getAccNo())
					.getBalance()) {
				System.out.println("Can't withdraw money.Your Account Balance is low.");
			} else {
				if (dao.hashMethod().containsKey(bankBeanWithdrawObj.getAccNo())) {
					float dep = dao.hashMethod().get(bankBeanWithdrawObj.getAccNo()).getBalance()
							- bankBeanWithdrawObj.getWithdrawAmount();
					dao.hashMethod().get(bankBeanWithdrawObj.getAccNo()).setBalance(dep);
					System.out.println("Withdraw successful.");
					System.out.println("Your account balance is: "
							+ dao.hashMethod().get(bankBeanWithdrawObj.getAccNo()).getBalance());
					value = dao.hashMethod().get(bankBeanWithdrawObj.getAccNo()).getBalance();
					long accountNumber = bankBeanWithdrawObj.getAccNo();
					String message = accountNumber + " is withdrawn with amount of"
							+ bankBeanWithdrawObj.getWithdrawAmount();
					transactionStorage.put(accountNumber, message);

				} else {
					System.out.println("No such Account Exist.");

				}

			}

		}
		return value;

	}

	public float transferService(Pojo bankBeanFundTransObj) {
		float value = 0;
		if (dao.hashMethod().isEmpty()) {

			System.out.println("Please create an account first.");

		}

		else {

			if (dao.hashMethod().containsKey(bankBeanFundTransObj.getSourceAccNo())) {

				if (dao.hashMethod().containsKey(bankBeanFundTransObj.getDestAccNo())) {

					if (dao.hashMethod().get(bankBeanFundTransObj.getSourceAccNo()).getBalance() > bankBeanFundTransObj
							.getTransferAmount()) {
						float transfer = bankBeanFundTransObj.getTransferAmount();
						dao.hashMethod().get(bankBeanFundTransObj.getSourceAccNo()).setBalance(
								dao.hashMethod().get(bankBeanFundTransObj.getSourceAccNo()).getBalance() - transfer);
						dao.hashMethod().get(bankBeanFundTransObj.getDestAccNo()).setBalance(
								dao.hashMethod().get(bankBeanFundTransObj.getDestAccNo()).getBalance() + transfer);
						System.out.println("Funds Transferred Successfully.");
						System.out.println(
								"Remaining balance in account number " + bankBeanFundTransObj.getSourceAccNo() + " is: "
										+ dao.hashMethod().get(bankBeanFundTransObj.getSourceAccNo()).getBalance());

						long accountNumber = bankBeanFundTransObj.getSourceAccNo();

						value = dao.hashMethod().get(bankBeanFundTransObj.getSourceAccNo()).getBalance();
						long accountNumberOfReceiver = bankBeanFundTransObj.getDestAccNo();

						String messageOfReceiver = accountNumberOfReceiver + "is deposited with amount of "
								+ bankBeanFundTransObj.getTransferAmount();
						String message = accountNumber + " is withdrawn with amount of"
								+ bankBeanFundTransObj.getTransferAmount();
						transactionStorage.put(accountNumber, message);
						transactionStorage.put(accountNumberOfReceiver, messageOfReceiver);
					} else {
						System.out.println("Can't transfer money. Source Account Balance is low.");
					}
				} else {
					System.out.println("Destination Account Not Exist.");
				}
			}

			else {
				System.out.println("Source Account Not Exist.");

			}

		}
		return value;
	}

	@Override
	public String printTransaction() {
		String val = null;
		for (Map.Entry mapping : transactionStorage.entrySet()) {
			System.out.println(mapping.getValue());
			val = (String) mapping.getValue();
		}
		return val;
	}

}