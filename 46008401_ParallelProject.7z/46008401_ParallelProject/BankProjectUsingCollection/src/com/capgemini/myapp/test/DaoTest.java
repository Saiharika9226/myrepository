package com.capgemini.myapp.test;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.myapp.dao.Dao;
import com.capgemini.myapp.pojo.*;

public class DaoTest {

	@Test
	public void testaddCustomer() {
		long accountNumber = 99889775;
		String name = "harika";
		long mobileNumber = 1234567890;
		float balance = 10000;
		Pojo testObject = new Pojo(accountNumber, name, mobileNumber, balance);
		Dao daoObject = new Dao();

		assertEquals(1, daoObject.addCustomer(testObject));
	}

	@Test
	public void testHashMethod() {
		Dao daoObjectHash = new Dao();
		assertNotNull(daoObjectHash.hashMethod());
	}

}
