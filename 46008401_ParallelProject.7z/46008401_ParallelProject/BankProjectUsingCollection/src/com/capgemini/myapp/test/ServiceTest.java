package com.capgemini.myapp.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.myapp.pojo.Pojo;
import com.capgemini.myapp.service.Service;

public class ServiceTest {

	@Test
	public void testBankAccountCreateService() {

		float balance = 10000;
		String name = "alekhya";
		long mobileNumber = 1234567890;
		long accountNumber = 1286913566;
		Pojo createAccountObject = new Pojo(accountNumber, name, mobileNumber, balance);
		Service serviceObject = new Service();

		assertEquals(1, serviceObject.bankAccountCreateService(createAccountObject));
	}

	@Test
	public void testBalanceService() {
		int accountNumber = 1286913566;
		Pojo showBalanceObject = new Pojo(accountNumber);
		Service serviceObject = new Service();
		assertNotNull(serviceObject.balanceService(showBalanceObject));
	}

	@Test
	public void testDepositService() {
		int accountNumber = 1286913566;
		float depositAmount = 1000;
		Pojo depositObj = new Pojo(accountNumber, depositAmount);
		Service serviceObject = new Service();

		assertNotNull(serviceObject.depositService(depositObj));

	}

	@Test
	public void testWithdrawService() {
		int accountNumber = 1286913566;
		float withdrawAmount = 1000;
		Pojo withdrawObject = new Pojo(withdrawAmount, accountNumber);
		Service serviceObj = new Service();
		assertNotNull(serviceObj.withdrawService(withdrawObject));
	}

	@Test
	public void testTransferService() {
		int sourceAccountNumber = 1286913566;
		int destinationAccountNumber = 2039999997;
		float transferAmount = 1000;
		Pojo FundTransferObject = new Pojo(sourceAccountNumber, destinationAccountNumber, transferAmount);
		Service serviceObj = new Service();
		assertNotNull(serviceObj.transferService(FundTransferObject));
	}
}
