/**
  @author Sai Harika.R
  Date 18/10/2019
  Description : It is the User defined exception which was created for the default case in switch case
 */
package com.capgemini.myapp.exception;

public class InvalidExecption extends RuntimeException {

	public InvalidExecption(String message) {
		System.out.println(message);
	}

}
