package com.capgemini.myapp.view;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.myapp.pojo.Pojo;
import com.capgemini.myapp.service.Service;

/**
 * @author Sai Harika.R 
 * Date 18/10/2019
 * Description Here the user gives the input and the inputs
 *
 */
public class ViewValidation {
	Service bankServiceObj = new Service();
	Scanner sc = new Scanner(System.in);

	public void accountCreation() {

		try {
			System.out.print("Enter Name: ");
			String name = nameCheck(sc.next());
			System.out.print("Enter Mobile No.: ");
			long mobileNumber = mobileNumberCheck(sc.nextLong());
			long accountNumber = 52345676 + mobileNumber;
			System.out.print("Enter Balance: ");
			float balance = amountCheck(sc.nextFloat());
			Pojo createAccountObject = new Pojo(accountNumber, name, mobileNumber, balance);
			System.out.println("Account created with Account Number: " + accountNumber);
			bankServiceObj.bankAccountCreateService(createAccountObject);
		} catch (InputMismatchException e) {
			System.err.println("Please enter the valid input");
		}
	}

	public void balanceCheck() {
		try {
			System.out.print("Enter Account Number: ");
			long accountNumber = sc.nextLong();
			Pojo showBalanceObject = new Pojo(accountNumber);

			bankServiceObj.balanceService(showBalanceObject);

		} catch (InputMismatchException e) {
			System.err.println("Please enter the valid input");
		}
	}

	public void deposit() {
		try {
			System.out.print("Enter Account Number: ");
			long accountNumber = sc.nextLong();
			System.out.print("Enter Deposit Amount: ");
			float depositAmount = amountCheck(sc.nextFloat());
			Pojo depositObj = new Pojo(accountNumber, depositAmount);

			bankServiceObj.depositService(depositObj);
		} catch (InputMismatchException e) {
			System.err.println("Please enter the valid input");
		}
	}

	public void withdraw() {

		try {
			System.out.print("Enter Account Number: ");
			long accountNumber = sc.nextLong();
			System.out.print("Enter Withdraw Amount: ");
			float withdrawAmount = amountCheck(sc.nextFloat());
			Pojo withdrawObject = new Pojo(withdrawAmount, accountNumber);
			bankServiceObj.withdrawService(withdrawObject);
		} catch (InputMismatchException e) {
			System.err.println("Please enter the valid input");
		}
	}

	public void fundTransfer() {
		try {
			System.out.println("Enter Sender Account Number: ");
			long sourceAccountNumber = sc.nextLong();
			System.out.println("Enter Receiver Account Number: ");
			long destinationAccountNumber = sc.nextLong();
			System.out.println("Enter Amount to transfer: ");
			float transferAmount = amountCheck(sc.nextFloat());
			Pojo fundTransferObject = new Pojo(sourceAccountNumber, destinationAccountNumber, transferAmount);
			bankServiceObj.transferService(fundTransferObject);
		} catch (InputMismatchException e) {
			System.err.println("Please enter the valid input");
		}
	}

	public void printTransactions() {
		bankServiceObj.printTransaction();
	}

	public float amountCheck(float amount) {
		while (true) {
			if (amount <= 1000) {
				System.out.println("Minimum Amount should be  1000.");
				System.out.println("Enter again: ");
				amount = sc.nextInt();
			} else {
				return amount;
			}
		}
	}

	public String nameCheck(String name) {
		while (true) {
			if (Pattern.matches("([A-Z])*([a-z])*", name)) {
				return name;
			} else {
				System.out.println("Name should only have alphabets.");
				System.out.println("Enter again: ");
				name = sc.next();
			}
		}
	}

	public long mobileNumberCheck(long mobileNumber) {
		while (true) {
			if (String.valueOf(mobileNumber).length() < 10) {
				System.out.println("Enter valid mobile number.");
				mobileNumber = sc.nextLong();
			} else {
				return mobileNumber;
			}
		}
	}
}