package com.capgemini.myapp.view;

import java.util.Scanner;
import com.capgemini.myapp.exception.InvalidExecption;

/**
 * @author Sai Harika.R 
 * Date 18/10/2019
 * Description It is the end user Interface
 *
 */
public class View {
	public static void main(String args[]) {

		int switchOption;
		char optionForContinue;
		ViewValidation objectForView = new ViewValidation();
		Scanner s = new Scanner(System.in);
		System.out.println("Welcome to XYZ Bank");
		do {
			System.out.println(
					" 1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transactions \n 7. Exit\n");
			System.out.print("Enter your choice : ");
			switchOption = s.nextInt();
			switch (switchOption) {
			case 1:
				objectForView.accountCreation();
				break;
			case 2:
				objectForView.balanceCheck();
				break;
			case 3:
				objectForView.deposit();
				break;
			case 4:
				objectForView.withdraw();
				break;
			case 5:
				objectForView.fundTransfer();
				break;
			case 6:
				objectForView.printTransactions();
			case 7:
				System.exit(0);
			default:
				try {
					throw new InvalidExecption("Invalid Option");
				} catch (InvalidExecption e) {
					System.err.println("Please enter valid option");
				}
			}
			System.out.print("Do You Want To Continue???? (y/n)...? : ");
			optionForContinue = s.next().charAt(0);
			if (optionForContinue == 'y' || optionForContinue == 'Y')
				continue;
			else {
				System.out.println("Thank You ! Use our services next time....");
				System.exit(0);
			}
		} while (switchOption != 7);
		s.close();
	}
}