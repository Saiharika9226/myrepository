/**
 * @author Sai Harika.R
 * Date 18/10/2019
 * Description 
 * From the view class all the variables are stored in pojo class object.
 *
 */
package com.capgemini.myapp.pojo;

public class Pojo {
	private long sourceAccountNumber, destinationAccountNumber;
	private float balance, depositAmount, withdrawAmount, transferAmount;
	private String name;
	private long mobileNumber, accountNumber;

	public Pojo() {

		super();

	}

	public Pojo(long accountNumber, String name, long mobileNumber, float balance) {
		this.accountNumber = accountNumber;
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.balance = balance;

	}

	public Pojo(long accountNumber) {
		this.accountNumber = accountNumber;

	}

	public Pojo(long accountNumber, float depositAmount) {
		this.accountNumber = accountNumber;
		this.depositAmount = depositAmount;

	}

	public Pojo(float withdrawAmount, long accountNumber) {
		this.withdrawAmount = withdrawAmount;
		this.accountNumber = accountNumber;
	}

	public Pojo(long sourceAccountNumber, long destinationAccountNumber, float transferAmount) {
		this.sourceAccountNumber = sourceAccountNumber;
		this.destinationAccountNumber = destinationAccountNumber;
		this.transferAmount = transferAmount;

	}

	public float getTransferAmount() {
		return transferAmount;

	}

	public void setTransferAmount(float transferAmount) {
		this.transferAmount = transferAmount;
	}

	public float getWithdrawAmount() {
		return withdrawAmount;
	}

	public void setWithdrawAmount(float withdrawAmount) {
		this.withdrawAmount = withdrawAmount;

	}

	public float getDepAmount() {
		return depositAmount;

	}

	public void setDepAmount(float depAmount) {
		this.depositAmount = depositAmount;

	}

	public long getAccNo() {
		return accountNumber;

	}

	public void setAccNo(long accountNumber) {
		this.accountNumber = accountNumber;

	}

	public long getSourceAccNo() {
		return sourceAccountNumber;

	}

	public void setSourceAccNo(long sourceAccountNumber) {
		this.sourceAccountNumber = sourceAccountNumber;

	}

	public long getDestAccNo() {
		return destinationAccountNumber;

	}

	public void setDestAccNo(long destinationAccountNumber) {
		this.destinationAccountNumber = destinationAccountNumber;

	}

	public float getBalance() {
		return balance;

	}

	public void setBalance(float balance) {
		this.balance = balance;

	}

	public String getName() {
		return name;

	}

	public void setName(String name) {
		this.name = name;

	}

	public long getMobNo() {
		return mobileNumber;

	}

	public void setMobNo(long mobileNumber) {
		this.mobileNumber = mobileNumber;

	}
}