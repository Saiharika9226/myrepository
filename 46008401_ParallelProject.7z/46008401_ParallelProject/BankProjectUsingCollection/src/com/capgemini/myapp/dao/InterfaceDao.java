/**
 * @author Sai Harika.R
 * Date 18/10/2019
 * 
 * Description 
 * Interface for the dao class.
 *
 */

package com.capgemini.myapp.dao;

import java.util.HashMap;

import com.capgemini.myapp.pojo.Pojo;

public interface InterfaceDao {
	public int addCustomer(Pojo beankBeanObj);

	public HashMap<Long, Pojo> hashMethod();
}
