/**
 * @author SAI HARIKA.R
 * Date 18/10/2019
 * 
 * Description 
 * Here the data is stored in collection.  Where the methods are implemented from interface
 */

package com.capgemini.myapp.dao;

import java.util.HashMap;
import com.capgemini.myapp.pojo.Pojo;

public class Dao implements InterfaceDao {
	Pojo beankBeanObj;
	HashMap<Long, Pojo> hashmap = new HashMap<Long, Pojo>();

	public int addCustomer(Pojo beankBeanObj) {
		this.beankBeanObj = beankBeanObj;
		hashmap.put(beankBeanObj.getAccNo(), beankBeanObj);
		int value = 0;
		if (hashmap.containsKey(beankBeanObj.getAccNo())) {
			value = 1;
		}

		return value;
	}

	public HashMap<Long, Pojo> hashMethod() {
		return hashmap;
	}

}
