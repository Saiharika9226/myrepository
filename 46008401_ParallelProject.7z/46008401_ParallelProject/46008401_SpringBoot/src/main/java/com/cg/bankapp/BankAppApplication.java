/**
 * @author Sai Harika.R
 * Date 05/12/2019
 * 
 * Description 
 * Bank Application using Spring Boot
 *
 */




package com.cg.bankapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankAppApplication.class, args);
	}

}
