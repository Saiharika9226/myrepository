package com.cg.exceptions;

public class InsufficientAccountException extends RuntimeException {
	public InsufficientAccountException() {
		System.out.println("Please enter valid balance");
		System.err.println("Insuffient balance");

	}

}
