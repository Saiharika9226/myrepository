/* 
 @ Rodda Sai Harika
 Date : 18/10/2019
 Description : Bank Application using JDBC
 
 */
package com.cg.exceptions;

public class InvalidAccountException extends RuntimeException {
	public InvalidAccountException() {
		System.out.println("Invalid account Number");
		System.out.println("Please enter valid accountId");
	}

}
