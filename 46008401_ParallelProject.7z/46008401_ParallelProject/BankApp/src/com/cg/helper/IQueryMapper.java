/* 
 @ Rodda Sai Harika
 Date : 18/10/2019
 Description : Bank Application using JDBC
 
 */

package com.cg.helper;

public interface IQueryMapper {
	public static final String INSERT_CUSTOMER = "insert into account1 values(?,?,?,?,?)";
	public static final String INSERT_TRANSACTION_DETAILS = "insert into printdetails values(?,?,?,?)";
	public static final String VIEW_TRANSACTION_DETAILS = "select * from printdetails";
	public static final String VIEW_BALANCE = "select BALANCE from ACCOUNT1 where ACCCOUNTID =";
	public static final String CHECK_ACCOUNT_ID = "select acccountId from account1";
	public static final String VIEW_DETAILS = "select * from printdetails where accountid=";
	public static final String UPDATE_DETAILS = "update account1 set balance = ? where acccountid =";

}
