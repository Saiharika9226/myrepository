/* 
 @ Rodda Sai Harika
 Date : 18/10/2019
 Description : Bank Application using JDBC
 
 */

package com.cg.dao;

import java.util.ArrayList;
import com.cg.model.Account;
import com.cg.model.Customer;
import com.cg.model.Transaction;

public interface IBankDAO {
	int create(Account account);

	double update(int accountId, double balance);

	double viewbalance(int accountId);

	void printDetails(int senderAccountId, int receiverAccountId, int creditedORWithdrawAmt, String statement);

	public ArrayList<Transaction> viewDetails(int accountId);

	public boolean checkAccountId(int accountId);
}