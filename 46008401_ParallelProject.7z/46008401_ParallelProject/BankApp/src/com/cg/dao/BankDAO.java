/* 
 @ Rodda Sai Harika
 Date : 18/10/2019
 Description : Bank Application using JDBC
 
 */
package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.management.Query;

import com.cg.helper.DBConnection;
import com.cg.helper.IQueryMapper;
import com.cg.model.Account;
import com.cg.model.Customer;
import com.cg.model.Transaction;

public class BankDAO implements IBankDAO {
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	double n;

	@Override

	// Creating an account
	public int create(Account account) {
		try {
			connection = DBConnection.getConnection();
			preparedStatement = connection.prepareStatement(IQueryMapper.INSERT_CUSTOMER);
			preparedStatement.setDouble(1, account.getAcccountId());
			preparedStatement.setString(2, account.getAccountType());
			preparedStatement.setDouble(3, account.getBalance());
			preparedStatement.setString(4, account.getCustname());
			preparedStatement.setString(5, account.getPhoneno());
			int n = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("your account is created");
		return 0;
	}

	// update account
	@Override
	public double update(int accountId, double balance) {
		connection = DBConnection.getConnection();
		double update = 0;
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.UPDATE_DETAILS + accountId);
			preparedStatement.setDouble(1, balance);
			update = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return update;
	}

	// view Balance
	@Override
	public double viewbalance(int accountId) {
		connection = DBConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_BALANCE + accountId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				n = resultSet.getDouble("BALANCE");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n;
	}

	// print Details
	@Override
	public void printDetails(int senderAccountId, int receiverAccountId, int creditedORWithdrawAmt, String statement) {
		ArrayList<Transaction> list = new ArrayList<>();
		try {
			connection = DBConnection.getConnection();
			preparedStatement = connection.prepareStatement(IQueryMapper.INSERT_TRANSACTION_DETAILS);
			preparedStatement.setInt(1, senderAccountId);
			preparedStatement.setInt(2, receiverAccountId);
			preparedStatement.setInt(3, creditedORWithdrawAmt);
			preparedStatement.setString(4, statement);
			int n = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// view Details
	public ArrayList<Transaction> viewDetails(int accountId) {
		ArrayList<Transaction> list = new ArrayList<Transaction>();
		connection = DBConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_DETAILS + accountId);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				Transaction transaction = new Transaction();
				transaction.setAaid(resultSet.getInt(1));
				transaction.setAccountid(resultSet.getInt(2));
				transaction.setAmount(resultSet.getInt(3));
				transaction.setMessage(resultSet.getString(4));
				list.add(transaction);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	// Checking account Id
	public boolean checkAccountId(int accountId) {
		boolean status = false;
		ArrayList<Transaction> list = new ArrayList<>();
		try {
			connection = DBConnection.getConnection();
			preparedStatement = connection.prepareStatement(IQueryMapper.CHECK_ACCOUNT_ID);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				if (resultSet.getInt(1) == accountId) {
					status = true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
}
