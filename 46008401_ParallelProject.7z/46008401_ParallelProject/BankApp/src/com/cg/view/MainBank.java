/* 
 @ Rodda Sai Harika
 Date : 18/10/2019
 Description : Bank Application using JDBC
 
 */
package com.cg.view;

import java.util.Scanner;
import com.cg.service.AccountController;
import com.cg.service.IAccount;

public class MainBank {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		IAccount accountInterface = new AccountController();
		System.out.println("welcome to XYZ BANK, Please choose the option");
		System.out.println("1 CreateAccount");
		System.out.println("2 ShowBalance");
		System.out.println("3 Deposit");
		System.out.println("4 WithDraw");
		System.out.println("5 TranferFunds");
		System.out.println("6 printTransaction");
		int input = scanner.nextInt();
		switch (input) {
		case 1:
			accountInterface.addCustomer();
			break;
		case 2:
			accountInterface.viewBalance();
			break;
		case 3:
			accountInterface.depositMoney();
			break;
		case 4:
			accountInterface.withdrawMoney();
			break;
		case 5:
			accountInterface.transferFunds();
			break;
		case 6:
			accountInterface.printDetails();
			break;
		default:
			System.out.println("Please Enter Valid Input");
			break;
		}
	}
}