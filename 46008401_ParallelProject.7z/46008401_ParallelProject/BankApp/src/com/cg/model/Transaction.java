/* 
 @ Rodda Sai Harika
 Date : 18/10/2019
 Description : Bank Application using JDBC
 
 */
package com.cg.model;

public class Transaction {
	private int senderAccountId;
	private int receiverAccountId;
	private int amount;
	private String message;

	public int getAccountid() {
		return senderAccountId;
	}

	public void setAccountid(int accountid) {
		this.senderAccountId = accountid;
	}

	public int getAaid() {
		return receiverAccountId;
	}

	public void setAaid(int receiverAccountId) {
		this.receiverAccountId = receiverAccountId;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "Transaction details are:" + " " + "accountid=" + senderAccountId + ", transferred to the acctid="
				+ receiverAccountId + ", amount=" + amount + ", message=" + message + "\n";
	}
}
