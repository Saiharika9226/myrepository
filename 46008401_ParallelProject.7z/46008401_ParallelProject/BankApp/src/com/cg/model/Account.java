/* 
 @ Rodda Sai Harika
 Date : 18/10/2019
 Description : Bank Application using JDBC
 
 */
package com.cg.model;

public class Account {
	private double accountId;
	private String accountType;
	private double balance;
	private double amount;
	private String customerName;
	private String phoneNo;

	public String getCustname() {
		return customerName;
	}

	public void setCustname(String customerName) {
		this.customerName = customerName;
	}

	public String getPhoneno() {
		return phoneNo;
	}

	public void setPhoneno(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public double getAmount(double amount, double balance) {
		amount = balance + amount;
		return amount;
	}

	public double withdraw(double balance, double amount) {
		balance = balance - amount;
		return balance;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountType=" + accountType + " ,]";
	}

	public double getAcccountId() {
		return accountId;
	}

	public void setAcccountId(double accountId) {
		this.accountId = accountId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
}
