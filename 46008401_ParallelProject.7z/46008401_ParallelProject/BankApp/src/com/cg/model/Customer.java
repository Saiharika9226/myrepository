/* 
 @ Rodda Sai Harika
 Date : 18/10/2019
 Description : Bank Application using JDBC
 
 */
package com.cg.model;

public class Customer {
	private int customerId;
	private String customerName;
	private double balance;

	public double getBal() {
		return balance;
	}

	public void setBal(double bal) {
		this.balance = bal;
	}

	private Account account;

	public int getCustId() {
		return customerId;
	}

	public void setCustId(int custId) {
		this.customerId = custId;
	}

	public String getCustname() {
		return customerName;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", account=" + account
				+ " , balance=" + balance + "]";
	}

	public void setCustname(String customerName) {
		this.customerName = customerName;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
}
