/* 
 @ Rodda Sai Harika
 Date : 18/10/2019
 Description : Bank Application using JDBC
 
 */
package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.dao.IBankDAO;
import com.cg.exceptions.InsufficientAccountException;
import com.cg.exceptions.InvalidAccountException;
import com.cg.dao.BankDAO;
import com.cg.model.Account;
import com.cg.model.Customer;
import com.cg.model.Transaction;

public class AccountController implements IAccount {
	Customer customer;
	Account account;
	IBankDAO bankDAOInterface;
	double updatedBalance;

	Scanner scanner = new Scanner(System.in);
	String regex = "(0/91)?[6-9][0-9]{9}";
	String savings = "savings";
	String current = "current";

	// Adding a customer
	public void addCustomer() {
		System.out.println("Enter account Type");
		String accountType = scanner.next();
		while (!accountType.equalsIgnoreCase(savings) && (!accountType.equalsIgnoreCase(current))) {
			System.err.println("Invalid....!, please enter valid account Type");
			accountType = scanner.next();
		}
		System.out.println("Enter customer Name");
		String customerName = scanner.next();
		System.out.println("Enter phone number");
		String phoneNo = scanner.next();
		int accountId = (int) (Math.random() * 1000000000);
		while (!phoneNo.matches(regex)) {
			System.err.println("Invalid....!, please enter valid phonenumber");
			phoneNo = scanner.next();
		}
		System.out.println("Your accountNo is : " + accountId);
		System.out.println("enter balance");
		double balance1 = scanner.nextDouble();
		account = new Account();
		account.setAcccountId(accountId);
		account.setAccountType(accountType);
		account.setCustname(customerName);
		account.setPhoneno(phoneNo);
		account.setBalance(balance1);
		List<Account> customerlist = new ArrayList<>();
		customerlist.add(account);
		bankDAOInterface = new BankDAO();
		bankDAOInterface.create(account);
	}

	// deposite money
	public void depositMoney() {
		bankDAOInterface = new BankDAO();
		System.out.println("Enter accountId");
		int accountId = scanner.nextInt();
		boolean status = bankDAOInterface.checkAccountId(accountId);
		while (!status) {
			try {
				throw new InvalidAccountException();
			} catch (InvalidAccountException e) {
				System.out.println("Please enter valid accountId");
			}
			accountId = scanner.nextInt();
			status = bankDAOInterface.checkAccountId(accountId);
		}
		System.out.println("Enter amount to deposit");
		int amountToDeposit = scanner.nextInt();
		account = new Account();
		updatedBalance = account.getAmount(amountToDeposit, bankDAOInterface.viewbalance(accountId));
		account.setBalance(updatedBalance);
		bankDAOInterface.update(accountId, updatedBalance);
		System.out.println("balance updated");
		String str = "deposited";
		bankDAOInterface.printDetails(accountId, accountId, amountToDeposit, str);
	}

	// withdraw money
	public void withdrawMoney() {
		bankDAOInterface = new BankDAO();
		System.out.println("enter accountId");
		int accountId = scanner.nextInt();
		boolean status = bankDAOInterface.checkAccountId(accountId);
		while (!status) {
			try {
				throw new InvalidAccountException();
			} catch (InvalidAccountException e) {
				System.out.println("Please enter valid accountId");
			}
			accountId = scanner.nextInt();
			status = bankDAOInterface.checkAccountId(accountId);
		}
		System.out.println("enter amount to withdraw");
		int amountToWithdraw = scanner.nextInt();
		account = new Account();
		double balance = bankDAOInterface.viewbalance(accountId);
		if (amountToWithdraw < 100 || ((amountToWithdraw % 100) != 0) || (amountToWithdraw > balance)) {
			System.err.println("invalid amount");
		} else {
			updatedBalance = account.withdraw(balance, amountToWithdraw);
			account.setBalance(updatedBalance);
			bankDAOInterface.update(accountId, updatedBalance);
			System.out.println("balance withdrawn");
			String str = "withdrawn";
			bankDAOInterface.printDetails(accountId, accountId, amountToWithdraw, str);
		}
	}

	// Transfer funds
	public void transferFunds() {
		bankDAOInterface = new BankDAO();
		System.out.println("Enter your accountId");
		int fromAccountId = scanner.nextInt();
		boolean status = bankDAOInterface.checkAccountId(fromAccountId);
		while (!status) {

			try {
				throw new InvalidAccountException();
			} catch (InvalidAccountException e) {
				e.printStackTrace();
			}
			fromAccountId = scanner.nextInt();
			status = bankDAOInterface.checkAccountId(fromAccountId);
		}
		System.out.println("Enter the accountId to whom you wanted to transfer");
		int toAccountId = scanner.nextInt();
		boolean flag = bankDAOInterface.checkAccountId(toAccountId);
		while (!flag) {
			try {
				throw new InvalidAccountException();
			} catch (InvalidAccountException e) {
				e.printStackTrace();
			}
			toAccountId = scanner.nextInt();
			status = bankDAOInterface.checkAccountId(toAccountId);
		}
		System.out.println("Enter amount to Transfer");
		int transferAmt = scanner.nextInt();
		account = new Account();
		double senderBalance = bankDAOInterface.viewbalance(fromAccountId);
		double receiverBalance = bankDAOInterface.viewbalance(toAccountId);
		if (transferAmt <= senderBalance) {
			senderBalance = senderBalance - transferAmt;
			receiverBalance = receiverBalance + transferAmt;
			bankDAOInterface.update(fromAccountId, senderBalance);
			bankDAOInterface.update(toAccountId, receiverBalance);
			System.out.println("transferd successfully!......");
			String str = "transferred";
			bankDAOInterface.printDetails(fromAccountId, toAccountId, transferAmt, str);
		} else {
			try {
				throw new InsufficientAccountException();
			} catch (InsufficientAccountException e) {
				// System.err.println("Insuffient balance");
			}
			// System.err.println("Insuffient balance");
		}
	}

	// show balance
	public void viewBalance() {
		bankDAOInterface = new BankDAO();
		System.out.println("Enter your accountId");
		int accountId = scanner.nextInt();
		boolean status = bankDAOInterface.checkAccountId(accountId);
		while (!status) {
			try {
				throw new InvalidAccountException();
			} catch (InvalidAccountException e) {
				e.printStackTrace();
			}
			accountId = scanner.nextInt();
			status = bankDAOInterface.checkAccountId(accountId);
		}
		System.out.println("Your account balance is : " + bankDAOInterface.viewbalance(accountId));

	}

	// print all the details
	@Override
	public void printDetails() {
		bankDAOInterface = new BankDAO();
		System.out.println("Enter your accound id");
		int accountId = scanner.nextInt();
		boolean status = bankDAOInterface.checkAccountId(accountId);
		while (!status) {
			try {
				throw new InvalidAccountException();
			} catch (InvalidAccountException e) {
				e.printStackTrace();
			}
			accountId = scanner.nextInt();
			status = bankDAOInterface.checkAccountId(accountId);
		}
		System.out.println(bankDAOInterface.viewDetails(accountId));
	}
}