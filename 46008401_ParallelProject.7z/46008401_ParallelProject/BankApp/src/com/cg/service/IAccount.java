/* 
 @ Rodda Sai Harika
 Date : 18/10/2019
 Description : Bank Application using JDBC
 
 */
package com.cg.service;

public interface IAccount {
	public void addCustomer();

	public void depositMoney();

	public void withdrawMoney();

	public void transferFunds();

	public void viewBalance();

	public void printDetails();
}