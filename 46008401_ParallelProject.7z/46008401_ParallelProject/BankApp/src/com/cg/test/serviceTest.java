/* 
 @ Rodda Sai Harika
 Date : 18/10/2019
 Description : Bank Application using JDBC
 
 */
package com.cg.test;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import org.junit.Test;

import com.cg.dao.BankDAO;
import com.cg.dao.IBankDAO;
import com.cg.helper.DBConnection;
import com.cg.helper.IQueryMapper;
import com.cg.service.AccountController;
import com.cg.service.IAccount;

public class serviceTest {
	private Connection con;
	private PreparedStatement ps;
	IBankDAO IbankDao;
	private ResultSet rs;
	Scanner sc = new Scanner(System.in);

	@Test
	public void testCheckAccountId() {
		IbankDao = new BankDAO();
		System.out.println("Enter accountId");
		int accountId = sc.nextInt();
		boolean flag = true;
		boolean status = IbankDao.checkAccountId(accountId);
		System.out.println(status);
		assertEquals(flag, status);
	}

	@Test
	public void viewbalance() {
		con = DBConnection.getConnection();
		double n = 0;
		try {
			ps = con.prepareStatement(IQueryMapper.VIEW_BALANCE + 905284165);
			rs = ps.executeQuery();
			while (rs.next()) {
				n = rs.getDouble("BALANCE");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		assertNotNull(n);

	}
}
