package com.cg.messagingapp.daos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.messagingapp.beans.CapBookChat;

/**
 *
 * @Author: Team 5
 *
 *          Date :17/12/2019
 *
 *          Description: DAO Interface For CapBookChat
 */
@Repository
public interface IChatDao extends JpaRepository<CapBookChat, Integer> {

	// Query to retrieve the last chat
	@Query(value = "select info from(select * from  chitchat where sender=?2 and receiver=?1 order by rowno desc) where rownum=1", nativeQuery = true)
	public String getreceivedmsg(String userEmailId, String receiverEmailId);

	// Query to retrieve all chats between two users
	@Query(value = "select info from chitchat where sender=?1 and receiver=?2", nativeQuery = true)
	public List<String> getAllChat(String userEmailId, String receiverEmailId);

	// Query to retrieve all the chats
	@Query(value = "select * from chitchat where receiver=?1", nativeQuery = true)
	public List<CapBookChat> getInbox(String receiverEmailId);

}
