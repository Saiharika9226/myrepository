package com.cg.messagingapp.services;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.messagingapp.beans.CapBookChat;
import com.cg.messagingapp.daos.IChatDao;
import com.cg.messagingapp.exceptions.NoChatException;

/**
 *
 * @Author: Team 5
 *
 *          Date :17/12/2019
 *
 *          Description: Service Implementation Class For CapBookChat
 */
@Service
public class ChatImpl implements IChatService {

	@Autowired
	private IChatDao IChatDao;

	// Method to save the message into database
	@Override
	public CapBookChat sendMessage(CapBookChat ChatMessage) {
		return IChatDao.save(ChatMessage);
	}

	// Method to get all the chats from database
	@Override
	public List<String> getAllChat(String userEmailId, String receiverEmailId) throws NoChatException {
		List<String> list = new ArrayList<>();
		list = IChatDao.getAllChat(userEmailId, receiverEmailId);
		if (list.isEmpty()) {
			throw new NoChatException("No Chat");
		} else {
			return IChatDao.getAllChat(userEmailId, receiverEmailId);
		}

	}

	// Method to get single message from the database
	@Override
	public List<String> getReceivedMessage(String userEmailId, String receiverEmailId) throws NoChatException {
		List<String> list = new ArrayList<String>();
		String message = IChatDao.getreceivedmsg(userEmailId, receiverEmailId);
		if (message == null) {
			throw new NoChatException("No Chat Available");
		} else {
			list.add(message);
		}
		return list;
	}

	// Method to get the inbox from database
	@Override
	public List<CapBookChat> getInbox(String receiverEmailId) throws NoChatException {
		List<CapBookChat> list = IChatDao.getInbox(receiverEmailId);
		if (list.size() == 0) {
			throw new NoChatException("No Chat Available");
		}
		return IChatDao.getInbox(receiverEmailId);

	}

	// Method to get the inbox count
	@Override
	public int getInboxCount(String receiverEmailId) {
		List<CapBookChat> list = IChatDao.getInbox(receiverEmailId);
		int count = list.size();

		return count;
	}

}
