package com.cg.messagingapp.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @Author: Team 5
 *
 *          Date :17/12/2019
 *
 *          Description: Bean Class For CapBookChat
 */
@Entity
@Table(name = "chitchat")
public class CapBookChat {
	@Id
	@GeneratedValue
	@Column(name = "rowno")
	private int rowId;
	@Column(name = "sender")
	private String userEmailId;
	@Column(name = "receiver")
	private String receiverEmailId;
	@Column(name = "info")
	private String message;

	public CapBookChat() {
		super();
	}

	// Getters and Setters
	public String getUserEmailId() {
		return userEmailId;
	}

	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}

	public String getReceiverEmailId() {
		return receiverEmailId;
	}

	public void setReceiverEmailId(String receiverEmailId) {
		this.receiverEmailId = receiverEmailId;
	}

	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
