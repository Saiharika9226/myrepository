package com.cg.messagingapp.exceptions;

/**
 *
 * @Author: Team 5
 *
 *          Date :17/12/2019
 *
 *          Description: Exception Class For CapBookChat
 */

public class NoChatException extends Exception {
	public NoChatException(String message) {
		super(message);
	}

}
