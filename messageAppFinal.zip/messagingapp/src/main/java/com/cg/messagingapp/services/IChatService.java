package com.cg.messagingapp.services;

import java.util.List;
import com.cg.messagingapp.beans.CapBookChat;
import com.cg.messagingapp.exceptions.NoChatException;

/**
 *
 * @Author: Team 5
 *
 *          Date :17/12/2019
 *
 *          Description: Service Interface For CapBookChat
 */
public interface IChatService {

	public List<String> getAllChat(String userEmailId, String receiverEmailId) throws NoChatException;

	public CapBookChat sendMessage(CapBookChat chat);

	public List<String> getReceivedMessage(String userEmailId, String receiverEmailId) throws NoChatException;

	public List<CapBookChat> getInbox(String receiverEmailId) throws NoChatException;

	public int getInboxCount(String receiverEmailId);

}
