package com.cg.messagingapp.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.messagingapp.beans.CapBookChat;
import com.cg.messagingapp.exceptions.NoChatException;
import com.cg.messagingapp.services.IChatService;

/**
 *
 * @Author: Team 5
 *
 *          Date :17/12/2019
 *
 *          Description: Controller Class For CapBookChat
 */
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ChatController {

	@Autowired
	private IChatService service;

	// Post method to post a message
	@RequestMapping(value = "chat/{userEmailId}/{receiverEmailId}/{message}", method = RequestMethod.POST)
	public CapBookChat sendMessage(@PathVariable String userEmailId, @PathVariable String receiverEmailId,
			@PathVariable String message) {
		CapBookChat chat = new CapBookChat();
		chat.setUserEmailId(userEmailId);
		chat.setReceiverEmailId(receiverEmailId);
		chat.setMessage(message);
		return service.sendMessage(chat);
	}

	// Get method to get a single chat
	@RequestMapping(value = "chat/{userEmailId}/{receiverEmailId}", method = RequestMethod.GET)
	public List<String> getReceivedMessage(@PathVariable String userEmailId, @PathVariable String receiverEmailId)
			throws NoChatException {
		return service.getReceivedMessage(userEmailId, receiverEmailId);
	}

	// Get method to get a all chat
	@RequestMapping(value = "getAll/{userEmailId}/{receiverEmailId}", method = RequestMethod.GET)
	public List<String> getAllChat(@PathVariable String userEmailId, @PathVariable String receiverEmailId)
			throws NoChatException {
		return service.getAllChat(userEmailId, receiverEmailId);
	}

	// Get method to get inbox messages
	@RequestMapping(value = "inbox/{receiverEmailId}", method = RequestMethod.GET)
	public List<CapBookChat> getInbox(@PathVariable String receiverEmailId) throws NoChatException {
		return service.getInbox(receiverEmailId);
	}

	// Get method to get a inbox count
	@RequestMapping(value = "inboxcount/{receiverEmailId}", method = RequestMethod.GET)
	public int getInboxCount(@PathVariable String receiverEmailId) {
		return service.getInboxCount(receiverEmailId);
	}

}
