package com.cg.messagingapp.runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 *
 * @Author: Team 5
 *
 *          Date :17/12/2019
 *
 *          Description: Runner Class For CapBookChat
 */
@RunWith(Cucumber.class)
@CucumberOptions(glue = ("com.cg.messagingapp.stepdef"), features = ("Features"), dryRun = false)
public class MessagingAppRunner {

}
