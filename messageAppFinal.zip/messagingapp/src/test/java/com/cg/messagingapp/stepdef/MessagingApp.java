package com.cg.messagingapp.stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @Author: Team 5
 *
 *          Date :17/12/2019
 *
 *          Description: MessagingApp Class For CapBookChat
 */
public class MessagingApp {

	@FindBy(xpath = "//*[@id=\'inputEmail\']")
	WebElement userEmail;

	@FindBy(xpath = "//*[@id=\'inputPassword\']")
	WebElement password;

	@FindBy(xpath = "//*[@id=\"Login\"]/button")
	WebElement login;

	@FindBy(xpath = "/html/body/app-root/app-home/div/div/a[1]")
	WebElement sendMessage;

	@FindBy(xpath = "//*[@id=\"Login\"]/div[1]/input")
	WebElement receiverEmail;

	@FindBy(xpath = "//*[@id=\"Login\"]/div[2]/input")
	WebElement typeMessage;

	@FindBy(xpath = "//*[@id=\"Login\"]/button[1]")
	WebElement sendMessageHome;

	@FindBy(xpath = "/html/body/app-root/app-home/div/div/a[3]")
	WebElement getAllMessages;

	@FindBy(xpath = "//*[@id=\"Login\"]/div/input")
	WebElement receiverEmailGetAll;

	@FindBy(xpath = "//*[@id=\"Login\"]/button[1]")
	WebElement getAll;

	@FindBy(xpath = "//*[@id=\"Login\"]/button[2]")
	WebElement back;

	@FindBy(xpath = "/html/body/app-root/app-home/div/div/a[4]")
	WebElement inbox;

	@FindBy(xpath = "//*[@id=\"Login\"]/button")
	WebElement inboxBack;

	public WebElement userEmail() {
		return userEmail;
	}

	public WebElement password() {
		return password;
	}

	public WebElement login() {
		return login;
	}

	public WebElement sendMessage() {
		return sendMessage;
	}

	public WebElement receiverEmail() {
		return receiverEmail;
	}

	public WebElement typeMessage() {
		return typeMessage;
	}

	public WebElement sendMessageHome() {
		return sendMessageHome;
	}

	public WebElement getAllMessages() {
		return getAllMessages;
	}

	public WebElement receiverEmailGetAll() {
		return receiverEmailGetAll;
	}

	public WebElement getAll() {
		return getAll;
	}

	public WebElement back() {
		return back;
	}

	public WebElement inbox() {
		return inbox;
	}

	public WebElement inboxBack() {
		return inboxBack;
	}

	public MessagingApp(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

}
