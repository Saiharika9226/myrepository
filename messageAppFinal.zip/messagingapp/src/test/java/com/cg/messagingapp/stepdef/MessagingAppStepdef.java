package com.cg.messagingapp.stepdef;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

/**
 *
 * @Author: Team 5
 *
 *          Date :17/12/2019
 *
 *          Description: Step Definition Class For CapBookChat
 */

public class MessagingAppStepdef {
	WebDriver driver;
	MessagingApp app;

	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\PPOOJA\\Documents\\chromedriver.exe");
		driver = new ChromeDriver();
		app = new MessagingApp(driver);
		driver.manage().window().maximize();
	}

	@Given("^User is on the Login page$")
	public void user_is_on_the_Login_page() throws Throwable {
		driver.get("http://localhost:4200/");

	}

	@Then("^Verify User is on Login Page$")
	public void verify_User_is_on_Login_Page() throws Throwable {

		Assert.assertEquals("MessagingApp", driver.getTitle());
		Thread.sleep(1500);
	}

	@When("^User enters Login Credentials and Login Button$")
	public void user_enters_Login_Credentials_and_Login_Button() throws Throwable {

		app.userEmail().sendKeys("pooja@capgemini.com");
		app.password().sendKeys("pooja");
		app.login().click();
		Thread.sleep(1500);
	}

	@Then("^Home Page should be displayed$")
	public void home_Page_should_be_displayed() throws Throwable {
		Assert.assertEquals("MessagingApp", driver.getTitle());
		Thread.sleep(1500);
	}

	@When("^User Clicks on Send Message Button$")
	public void user_Clicks_on_Send_Message_Button() throws Throwable {

		app.sendMessage().click();
		Thread.sleep(1500);
	}

	@Then("^Send Message Page Should be displayed$")
	public void send_Message_Page_Should_be_displayed() throws Throwable {
		Assert.assertEquals("MessagingApp", driver.getTitle());
		Thread.sleep(1500);
	}

	@When("^User enters Receiver Email Id and Message and clicks on send Message button$")
	public void user_enters_Receiver_Email_Id_and_Message_and_clicks_on_send_Message_button() throws Throwable {
		app.receiverEmail().sendKeys("harika@capgemini.com");
		app.typeMessage().sendKeys("Hello Pooja");
		app.sendMessageHome().click();
		Thread.sleep(1500);

	}

	@Then("^Message sent Successfully alert box should appear$")
	public void message_sent_Successfully_alert_box_should_appear() throws Throwable {
		Alert alert = driver.switchTo().alert();
		Assert.assertEquals("message sent successfully", alert.getText());
		Thread.sleep(1500);
		alert.accept();
		Thread.sleep(1500);

	}

	@Given("^Receiver is on his Login page$")
	public void receiver_is_on_his_Login_page() throws Throwable {

		driver.get("http://localhost:4200/");
		Thread.sleep(1500);

	}

	@Then("^Verify Receiver is on Login Page$")
	public void verify_Receiver_is_on_Login_Page() throws Throwable {
		Assert.assertEquals("MessagingApp", driver.getTitle());
		Thread.sleep(1500);

	}

	@When("^Receiver enters Login Credentials and Login Button$")
	public void receiver_enters_Login_Credentials_and_Login_Button() throws Throwable {

		app.userEmail().sendKeys("harika@capgemini.com");
		app.password().sendKeys("haari");
		app.login().click();
		Thread.sleep(1500);
	}

	@When("^User clicks on Get All Messages Button$")
	public void user_clicks_on_Get_All_Messages_Button() throws Throwable {
		app.getAllMessages().click();
		Thread.sleep(2000);

	}

	@Then("^Get All Messages Page should be displayed$")
	public void get_All_Messages_Page_should_be_displayed() throws Throwable {
		Assert.assertEquals("MessagingApp", driver.getTitle());
		Thread.sleep(1500);

	}

	@When("^User Enters Receiver Email Id and clicks on GetAll button$")
	public void user_Enters_Receiver_Email_Id_and_clicks_on_GetAll_button() throws Throwable {
		app.receiverEmailGetAll().sendKeys("harika@capgemini.com");
		app.getAll().click();
		Thread.sleep(1500);
	}

	@Then("^All Messages should be displayed$")
	public void all_Messages_should_be_displayed() throws Throwable {
		Assert.assertEquals("MessagingApp", driver.getTitle());
		Thread.sleep(1500);

	}

	@When("^User Clicks on Back Button$")
	public void user_Clicks_on_Back_Button() throws Throwable {
		app.back().click();
		Thread.sleep(1500);

	}

	@Then("^Home Page Should be displayed$")
	public void home_Page_Should_be_displayed() throws Throwable {
		Assert.assertEquals("MessagingApp", driver.getTitle());
		Thread.sleep(1500);
	}

	@When("^User Clicks on Inbox Button$")
	public void user_Clicks_on_Inbox_Button() throws Throwable {
		app.inbox().click();
		Thread.sleep(1500);

	}

	@Then("^Inbox page should be displayed$")
	public void inbox_page_should_be_displayed() throws Throwable {
		Assert.assertEquals("MessagingApp", driver.getTitle());
		Thread.sleep(1500);

	}

	@When("^User Clicks on Back Button in Inbox Page$")
	public void user_Clicks_on_Back_Button_in_Inbox_Page() throws Throwable {
		app.inboxBack().click();
		Thread.sleep(1500);

	}

	@After
	public void closeApplication() {
		driver.close();
	}

}
