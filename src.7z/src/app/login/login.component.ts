import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit,OnDestroy {

  ngOnDestroy(){
    this.data.userEmailId=this.userEmailId 
  }
  userEmailId:String;
  password:String;
  constructor(private data:DataService,private router:Router) { }

  login(userEmailId,password){
   if(userEmailId==null && password==null ){
    
    this.router.navigate([''])
   }
   else
   {
     this.router.navigate(['home'])
   }
  }

  ngOnInit() {
    
  }


}
