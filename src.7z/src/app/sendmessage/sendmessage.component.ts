import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-sendmessage',
  templateUrl: './sendmessage.component.html',
  styleUrls: ['./sendmessage.component.scss']
})
export class SendmessageComponent implements OnInit {

  constructor(private service : ProductService,private router:Router,private data:DataService) { }
  
  userEmailId:String;
  ngOnInit() {
    this.userEmailId=this.data.userEmailId
  }

  sendmsg(userEmailId,receiverEmailId,message){
    if(receiverEmailId==null){
      this.router.navigate(['home/sendmsg'])
    }

    this.service.sendmsg(userEmailId,receiverEmailId,message).subscribe(()=> {
      alert('message sent successfully')
      this.router.navigate(['home'])
    }
    )
  }

  back(){
    this.router.navigate(['home'])
  }

  

}
