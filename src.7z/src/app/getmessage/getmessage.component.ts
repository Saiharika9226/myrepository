import { Component, OnInit, } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { DataService } from '../data.service';

@Component({
  selector: 'app-getmessage',
  templateUrl: './getmessage.component.html',
  styleUrls: ['./getmessage.component.scss']
})
export class GetmessageComponent implements OnInit {
  
  

  chats;
  receiverid:String;
  userEmailId:String;
  constructor(private service : ProductService,private router:Router,private data:DataService) { }

  ngOnInit() {
    this.userEmailId=this.data.userEmailId
  }

  getchat(userEmailId,receiverEmailId){
    this.service.getchat(userEmailId,receiverEmailId).subscribe((res) => this.chats=res)
   }
  
   back(){
    this.router.navigate(['home'])
  }



}
