import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { DataService } from '../data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  count;

  userEmailId;
  constructor(private router:Router,private service:ProductService,private data:DataService) { 
     this.userEmailId=this.data.userEmailId
     this.service.getInboxCount(this.userEmailId).subscribe((res) => this.count=res)
    }

  ngOnInit() {
    
  }

  back(){
    this.router.navigate([''])
  }


}
