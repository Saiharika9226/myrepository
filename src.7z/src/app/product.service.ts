import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
 
@Injectable({
 providedIn: 'root'
})
export class ProductService {
 
 
constructor(private http:HttpClient) { }

getAll(userEmailId:String,receiverEmailId:String){
    return this.http.get('http://localhost:9099/getAll/'+userEmailId+'/'+receiverEmailId)
    }

getchat(userEmailId:number,receiverEmailId:number){
        return this.http.get('http://localhost:9099/chat/'+userEmailId+'/'+receiverEmailId)
        }

sendmsg(userEmailId,receiverEmailId,message){
    return this.http.post('http://localhost:9099/chat/'+userEmailId+'/'+receiverEmailId+'/'+message,null)
     }

getInbox(receiverEmailId){
    return this.http.get('http://localhost:9099/inbox/'+receiverEmailId)   
}

getInboxCount(receiverEmailId){
    return this.http.get('http://localhost:9099/inboxcount/'+receiverEmailId)
}

}