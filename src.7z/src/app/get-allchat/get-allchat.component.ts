import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-get-allchat',
  templateUrl: './get-allchat.component.html',
  styleUrls: ['./get-allchat.component.scss']
})
export class GetAllchatComponent implements OnInit {

  constructor(private service :ProductService, private router:Router,private data:DataService) { }
  chats;
  anotherchat;
  inbox;
  userEmailId:String
  receiverEmailId:String
  ngOnInit() {
    this.userEmailId=this.data.userEmailId
  }


  getAllchat(userEmailId,receiverEmailId){
   this.service.getAll(userEmailId,receiverEmailId).subscribe((res) => this.chats=res)
   this.service.getAll(receiverEmailId,userEmailId).subscribe((res) => this.anotherchat=res)
  }
  
  back(){
    this.router.navigate(['home'])
  }

}
