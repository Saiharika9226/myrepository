import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAllchatComponent } from './get-allchat.component';

describe('GetAllchatComponent', () => {
  let component: GetAllchatComponent;
  let fixture: ComponentFixture<GetAllchatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetAllchatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetAllchatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
