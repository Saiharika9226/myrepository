import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { DataService } from '../data.service';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss']
})
export class InboxComponent implements OnInit {

  constructor(private service :ProductService, private router:Router,private data:DataService) { }
  count;
  inbox;
  userEmailId:String;

  ngOnInit() {
    this.userEmailId=this.data.userEmailId
    this.service.getInbox(this.userEmailId).subscribe((res) => this.inbox=res)

  }
 
  back(){
    this.router.navigate(['home'])
  }


}
