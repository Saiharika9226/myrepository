import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { GetmessageComponent } from './getmessage/getmessage.component';
import { GetAllchatComponent } from './get-allchat/get-allchat.component';
import { SendmessageComponent } from './sendmessage/sendmessage.component';
import { LoginComponent } from './login/login.component';
import { InboxComponent } from './inbox/inbox.component';



const routes: Routes = [
{path:'home',component:HomeComponent},
{path:'home/getmessage', component:GetmessageComponent},
{path:'home/getAllchat', component:GetAllchatComponent},
{path:'home/sendmsg',component:SendmessageComponent },
{path:'',component: LoginComponent},
{path:'home/inbox',component:InboxComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
