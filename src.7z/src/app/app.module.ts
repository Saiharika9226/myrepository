import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from "@angular/forms";
import { GetmessageComponent } from './getmessage/getmessage.component';
import { GetAllchatComponent } from './get-allchat/get-allchat.component';
import { SendmessageComponent } from './sendmessage/sendmessage.component';
import { LoginComponent } from './login/login.component';
import { InboxComponent } from './inbox/inbox.component';
import { DataService } from './data.service';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    GetmessageComponent,
    GetAllchatComponent,
    SendmessageComponent,
    LoginComponent,
    InboxComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [DataService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
